#!/usr/bin/env bash
# Studio Go / Bridge healthcheck
set -euo pipefail

URL="${BRIDGE_URL:-https://bridge-service-xxxxxxxxxx-uc.a.run.app}"
KEY="${BRIDGE_KEY:-}"

echo "=== Bridge Healthcheck ==="
echo "URL: $URL"
echo

# 1. Public root
ROOT_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL/" || echo "000")
echo "root:              $ROOT_CODE"

# 2. Protected bridge without key (expect 403)
NOKEY_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
  -X POST "$URL/bridge" \
  -H "Content-Type: application/json" \
  -d '{"ping":1}' || echo "000")
echo "bridge_no_key:     $NOKEY_CODE  (expect 403)"

# 3. Protected bridge with key (expect 200 or 202)
if [[ -z "$KEY" ]]; then
  echo "bridge_with_key:   SKIPPED (BRIDGE_KEY not set)"
else
  WITHKEY_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST "$URL/bridge" \
    -H "Content-Type: application/json" \
    -H "x-bridge-key: $KEY" \
    -d '{"ping":1}' || echo "000")
  echo "bridge_with_key:   $WITHKEY_CODE  (expect 200/202)"
fi

echo
echo "Done."
