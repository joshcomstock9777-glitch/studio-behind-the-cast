// Studio Go — Core Types
// Everything modular and packable. No hard-coded providers or keys.

export type SeatStatus =
  | 'listening'
  | 'thinking'
  | 'waiting'
  | 'speaking'
  | 'muted'
  | 'offline';

export interface Seat {
  id: string;
  name: string;
  avatar?: string;
  color: string;
  status: SeatStatus;
  provider?: string;
  model?: string;
  voiceId?: string;
  profileId?: string | null;
  enabled: boolean;
  muted: boolean;
  isEditorCapable?: boolean;
}

export type TopMode =
  | 'room'
  | 'speaker'
  | 'notes'
  | 'reference'
  | 'shotlist'
  | 'tasks'
  | 'prompt'
  | 'info';

export type WorkSurface =
  | 'editor'
  | 'audio'
  | 'browser'
  | 'media'
  | 'notebook'
  | 'markup'
  | 'text'
  | 'preview';

export type ToolPanelState = 'collapsed' | 'half' | 'full' | 'locked';

export type OrchestratorMode =
  | 'natural'
  | 'round_robin'
  | 'brainstorm'
  | 'one_speaker'
  | 'everyone_brief';

export type FloorState =
  | 'listening'
  | 'decide_speaker'
  | 'generating'
  | 'speaking'
  | 'floor_open';

export interface TranscriptEntry {
  id: string;
  seatId: string | 'human' | 'system';
  name: string;
  text: string;
  timestamp: number;
  isPartial?: boolean;
}

export interface ExpertProfile {
  id: string;
  name: string;
  description?: string;
  prompt: string;
  tags?: string[];
  isEditorCapable?: boolean;
}

export interface Project {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  transcript: TranscriptEntry[];
  mediaRefs: string[];
  notesRefs: string[];
  annotationRefs: string[];
  profileIds: string[];
  editorStateRef?: string;
}

export type EditorCommand =
  | { type: 'load_media'; payload: { uri: string; name?: string } }
  | { type: 'play' }
  | { type: 'pause' }
  | { type: 'seek'; payload: { time: number } }
  | { type: 'split' }
  | { type: 'trim_start' }
  | { type: 'trim_end' }
  | { type: 'move_clip'; payload: { clipId: string; toTime: number } }
  | { type: 'duplicate_clip' }
  | { type: 'delete_clip' }
  | { type: 'add_text'; payload: { text: string } }
  | { type: 'adjust_volume'; payload: { level: number } }
  | { type: 'mute_track' }
  | { type: 'add_fade'; payload: { in?: number; out?: number } }
  | { type: 'undo' }
  | { type: 'redo' }
  | { type: 'save_project' }
  | { type: 'export_preview' }
  | { type: 'show_frame'; payload: { time: number } }
  | { type: 'select_clip'; payload: { clipId: string } };

export interface EditorAdapter {
  execute: (cmd: EditorCommand) => Promise<{ ok: boolean; message?: string }>;
  canExecute: (cmd: EditorCommand) => boolean;
}
